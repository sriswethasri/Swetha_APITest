package com.country.api.test;

public interface CountryAPIConstant {

	static final String BASE_URL = "https://restcountries.eu/rest/v2/alpha/";
}
